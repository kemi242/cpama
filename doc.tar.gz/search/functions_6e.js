var searchData=
[
  ['norm1',['norm1',['../class_c_p_a_m_a_1_1_matrix.html#a143a7407184d09441fa18e7562c61919',1,'CPAMA::Matrix']]],
  ['norm2',['norm2',['../class_c_p_a_m_a_1_1_matrix.html#ae4e41b865044b2ee6f4ee9b14f87b3c3',1,'CPAMA::Matrix::norm2()'],['../class_c_p_a_m_a_1_1_singular_value_decomposition.html#abc881810c230810e655b5da8d3ad9cbc',1,'CPAMA::SingularValueDecomposition::norm2()']]],
  ['normf',['normF',['../class_c_p_a_m_a_1_1_matrix.html#ab9a47d9f0bd089f9c801b9573b203480',1,'CPAMA::Matrix']]],
  ['norminf',['normInf',['../class_c_p_a_m_a_1_1_matrix.html#a2b1009bc00c8e71c659f2aef7a7d2224',1,'CPAMA::Matrix']]]
];

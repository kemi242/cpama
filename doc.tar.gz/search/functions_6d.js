var searchData=
[
  ['matrix',['Matrix',['../class_c_p_a_m_a_1_1_matrix.html#a75e25f70a760fa9625afa33a3c44af8f',1,'CPAMA::Matrix::Matrix(int m, int n)'],['../class_c_p_a_m_a_1_1_matrix.html#a58e90c7eaf51d8c9377f0b1d41434a96',1,'CPAMA::Matrix::Matrix(int m, int n, double s)'],['../class_c_p_a_m_a_1_1_matrix.html#a3f893b138986234b89501127235ceb40',1,'CPAMA::Matrix::Matrix(double **A, int m, int n)'],['../class_c_p_a_m_a_1_1_matrix.html#a18adc7f866bf494c151c4fb2f9d417e6',1,'CPAMA::Matrix::Matrix(double *vals, int m, int valslen)'],['../class_c_p_a_m_a_1_1_matrix.html#abcf708e864ed3d9db2c3b317c5e529ab',1,'CPAMA::Matrix::Matrix(const Matrix &amp;other)']]]
];

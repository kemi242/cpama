var searchData=
[
  ['det',['det',['../class_c_p_a_m_a_1_1_l_u_decomposition.html#a351bceb882acd570daba62b19fb93c16',1,'CPAMA::LUDecomposition::det()'],['../class_c_p_a_m_a_1_1_matrix.html#ace95025dd985ddaa6c1ed72e8b464a0a',1,'CPAMA::Matrix::det()']]]
];

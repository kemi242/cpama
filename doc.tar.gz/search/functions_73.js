var searchData=
[
  ['set',['set',['../class_c_p_a_m_a_1_1_matrix.html#aa8bf1500336abec8a588ff2fe9f1e113',1,'CPAMA::Matrix']]],
  ['setmatrix',['setMatrix',['../class_c_p_a_m_a_1_1_matrix.html#a85cd86e2ecd32798cae7ca14e01d8bc6',1,'CPAMA::Matrix::setMatrix(int i0, int i1, int j0, int j1, Matrix X)'],['../class_c_p_a_m_a_1_1_matrix.html#a61c8f2db365ba563708b47b9be47e473',1,'CPAMA::Matrix::setMatrix(int *r, int rlen, int *c, int clen, Matrix X)'],['../class_c_p_a_m_a_1_1_matrix.html#a17028effba2bf0652bb7408cce0cbf5f',1,'CPAMA::Matrix::setMatrix(int *r, int rlen, int j0, int j1, Matrix X)'],['../class_c_p_a_m_a_1_1_matrix.html#a5a8e5ea77bb20715d91e8a06b44e38e1',1,'CPAMA::Matrix::setMatrix(int i0, int i1, int *c, int clen, Matrix X)']]],
  ['singularvaluedecomposition',['SingularValueDecomposition',['../class_c_p_a_m_a_1_1_singular_value_decomposition.html#a718383f0d43388e37af198d3865324b8',1,'CPAMA::SingularValueDecomposition']]],
  ['solve',['solve',['../class_c_p_a_m_a_1_1_cholesky_decomposition.html#afb4f0dd2f5a9b8bedcc4a4c19090b469',1,'CPAMA::CholeskyDecomposition::solve()'],['../class_c_p_a_m_a_1_1_l_u_decomposition.html#a028ede9f7a033dbb6d715f3291256396',1,'CPAMA::LUDecomposition::solve()'],['../class_c_p_a_m_a_1_1_matrix.html#a682b454f3e1187d144d07f4d90500899',1,'CPAMA::Matrix::solve()'],['../class_c_p_a_m_a_1_1_q_r_decomposition.html#a68490c07dd5bba79915dec34eaa8b663',1,'CPAMA::QRDecomposition::solve()']]],
  ['solvetranspose',['solveTranspose',['../class_c_p_a_m_a_1_1_matrix.html#a5f5ab53e823663d10a3e2c227e1cf08c',1,'CPAMA::Matrix']]],
  ['svd',['svd',['../class_c_p_a_m_a_1_1_matrix.html#aecfcd618410316390e8b41d0fad824d5',1,'CPAMA::Matrix']]]
];

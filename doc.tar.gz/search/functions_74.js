var searchData=
[
  ['trace',['trace',['../class_c_p_a_m_a_1_1_matrix.html#af7403d8c02553a4fba253380e4e0bc40',1,'CPAMA::Matrix']]],
  ['transpose',['transpose',['../class_c_p_a_m_a_1_1_matrix.html#ae23f817021383e3c8636a714dcba1d21',1,'CPAMA::Matrix']]]
];
